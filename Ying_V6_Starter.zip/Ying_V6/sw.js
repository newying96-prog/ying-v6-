const CACHE="ying-v6-cache";const FILES=["./","./index.html","./styles.css","./app.js","./manifest.webmanifest","./assets/ying-avatar.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener("fetch",e=>{if(e.request.method==="GET")e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));});
